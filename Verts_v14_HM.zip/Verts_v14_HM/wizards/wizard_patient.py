from odoo import models, fields, api


class ChangePassword(models.TransientModel):
    _name = 'change.password'

    def update_record(self):
        active_id = self._context.get('active_id')
        record_to_update = self.env['hospital.patient'].browse(active_id)
        if record_to_update.exists():
            vals = {
                'patient_name': self.patient_name,
                'patient_dob': self.patient_dob,
                'patient_mob_no': self.patient_mob_no,
            }
            record_to_update.write(vals)

    def change_password(self):
        pass
    patient_name = fields.Char(string='patient_name', compute='update_record')
    patient_dob = fields.Date(string='patient_dob')
    patient_mob_no = fields.Integer(string='Mob_Number')
