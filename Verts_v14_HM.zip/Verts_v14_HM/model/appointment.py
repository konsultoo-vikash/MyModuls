from odoo import fields, models


class HospitalAppointment(models.Model):
    _name = 'hospital.appointment'

                                  # odoo field
    appointment_id = fields.Char(string='appointment id')
    appointment_date = fields.Date(string='appointment date')
    patient_appointment = fields.Many2one('hospital.doctor', string='Patient Appointment Doctor Name')
    patient_medicine_name = fields.Many2many('hospital.pharmacy', 'medicine_name', string='Patient Medicine')


class PatientAppointment(models.Model):
    _name = 'doctor.appointment'

    doctor_name1 = fields.Many2one('hospital.doctor', string='Doctor Information')
    specialisation = fields.Char(string='Doctor Specialisation')


