import base64
from io import BytesIO

from dateutil.relativedelta import relativedelta

from odoo import fields, models, api, _
import xlwt

from odoo.tools.safe_eval import datetime


class HospitalPatient(models.Model):
    _name = 'hospital.patient'
    _rec_name = 'patient_id'

                            #campute fields
    @api.depends('age_group')
    def set_age_group(self):
        for rec in self:
            if rec.patient_age:
                if rec.patient_age < 18:
                    rec.age_group = 'major'
                else:
                    rec.age_group = 'minor'

    def open_patient_appointment(self):
        return {
            'name': _('Appointment'),
            'domain': [],
            'view_id': False,
            'res_model': 'hospital.appointment',
            'view_mode': 'tree,form',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
        }

    @api.depends
    def get_appointment_count(self):
        count = self.env['hospital.appointment'].serch_count([('patient_id', '=', self.id)])
        self.appointment_count = count

                                #odoo fields
    appointment_count = fields.Integer(string="Appointment Count", compute='get_appointment_count')
    patient_name = fields.Char(string='patient name')
    patient_id = fields.Char(string='patient_id')
    patient_age = fields.Integer(string='age')
    country_id = fields.Many2one('res.country', string='Country')
    gender = fields.Selection([('male', 'Male'),
                               ('female', 'Female'),
                               ('others', 'Others')], string='Gender')
    image = fields.Binary(string='Image')
    patient_mobile_no = fields.Char(string='Mobile')
    patient_dob = fields.Date(string='Date of Birth', compute='_onchange_birth_date')
    age_group = fields.Selection([
        ('major', 'Major'),
        ('minor', 'Minor'),
        ], string='age group', compute='set_age_group')
    calculated_date = fields.Char(string='Total Age')

         #method onchange

    @api.onchange('patient_dob')
    def _onchange_birth_date(self):
        for rec in self:
            if rec.patient_dob:
                print('self.patient_dob', rec.patient_dob)
                years = relativedelta(datetime.now(), rec.patient_dob).years
                months = relativedelta(datetime.now(), rec.patient_dob).months
        # for _ in self:
        rec.calculated_date = str(int(years)) + ' Years ' + str(int(months)) + ' Months '
        #     print('calculated_age')
        #     print('============================================')


                    # Method to generate excel report

    def print_report_excel(self):
        wb = xlwt.Workbook(encoding='utf-8')
        sheet = wb.add_sheet("Sheet1", cell_overwrite_ok=True)

        # All styles below


        style_blue_li = xlwt.easyxf('align: horiz centre; font: colour black, bold True; '
                                    'borders: top_color black, bottom_color black, right_color black, left_color black,\
                                      left thin, right thin, top thin, bottom thin;\
                                    pattern: pattern solid, fore_color 0x28;')
        style_blue_dk = xlwt.easyxf('align: horiz centre; font: colour white, bold True; '
                                    'borders: top_color black, bottom_color black, right_color black, left_color black,\
                                      left thin, right thin, top thin, bottom thin;\
                                    pattern: pattern solid, fore_color 0x1E;')
        style_or_li = xlwt.easyxf('align: horiz centre; align: vert centre; font: colour black, bold True; '
                                  'borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;\
                                  pattern: pattern solid, fore_color 0x34;')
        style_or_dk = xlwt.easyxf('align: horiz centre; font: colour white, bold True; '
                                  'borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;\
                                  pattern: pattern solid, fore_color 0x35;')
        style_grey_li = xlwt.easyxf('align: horiz centre; align: vert centre; font: colour black, bold True; '
                                    'borders: top_color black, bottom_color black, right_color black, left_color black,\
                                      left thin, right thin, top thin, bottom thin;\
                                    pattern: pattern solid, fore_color 0x37;')
        style_grey_dk = xlwt.easyxf('align: horiz centre; align: vert centre; font: colour white, bold True; '
                                    'borders: top_color black, bottom_color black, right_color black, left_color black,\
                                      left thin, right thin, top thin, bottom thin;\
                                    pattern: pattern solid, fore_color 0x3F;')
        style_green_li = xlwt.easyxf('align: horiz centre; align: vert centre; font: colour black, bold True; '
                                     'borders: top_color black, bottom_color black, right_color black, left_color black,\
                                       left thin, right thin, top thin, bottom thin;\
                                     pattern: pattern solid, fore_color 0x11;')
        style_green_dk = xlwt.easyxf('align: horiz centre; align: vert centre; font: colour white, bold True; '
                                     'borders: top_color black, bottom_color black, right_color black, left_color black,\
                                       left thin, right thin, top thin, bottom thin;\
                                     pattern: pattern solid, fore_color 0x3A;')
        style_black = xlwt.easyxf('align: horiz centre; align: vert centre; font: colour white, bold True; '
                                  'borders: top_color black, bottom_color black, right_color black, left_color black,\
                                    left thin, right thin, top thin, bottom thin;\
                                  pattern: pattern solid, fore_color black;')
        style = xlwt.easyxf('font: bold 1; align: horiz centre; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                                  left thin, right thin, top thin, bottom thin;\
                                        pattern: pattern solid, fore_color white;')
        style_wrap = xlwt.easyxf('font: bold 1; align: wrap True')
        borders = xlwt.easyxf('align: horiz centre; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                                  left thin, right thin, top thin, bottom thin;\
                                                pattern: pattern solid, fore_color white;')
        borders_yel = xlwt.easyxf('align: horiz centre; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                                  left thin, right thin, top thin, bottom thin;\
                                                pattern: pattern solid, fore_color yellow;')
        borders_red = xlwt.easyxf('align: horiz centre; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                                          left thin, right thin, top thin, bottom thin;\
                                                        pattern: pattern solid, fore_color red;')
        borders_gr = xlwt.easyxf('align: horiz centre; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                                                  left thin, right thin, top thin, bottom thin;\
                                                                pattern: pattern solid, fore_color green;')
        style1 = xlwt.easyxf('font: bold 1; align: vert centre;')
        style1_bor = xlwt.easyxf('font: bold 1; align: vert centre; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                                  left thin, right thin, top thin, bottom thin;\
                                        pattern: pattern solid, fore_color white;')
        borders = xlwt.easyxf('borders: top_color black, bottom_color black, right_color black, left_color black,\
                                                  left thin, right thin, top thin, bottom thin;\
                                         pattern: pattern solid, fore_color white;')
        bold_borders_or = xlwt.easyxf('font: bold 1; align: horiz centre; borders: top_color black, bottom_color black, right_color black, left_color black,\
                                                                  left thin, right thin, top thin, bottom thin;\
                  left thin, right thin, top thin, bottom thin;\
                                                        pattern: pattern solid, fore_colour custom_colour_or;')
        style_red = xlwt.easyxf('font: bold 1, color red; align: vert centre;')
        style_blue = xlwt.easyxf('font: bold 1, color blue; align: vert centre;')

       # all Data below

        sheet.write_merge(0, 2, 0, 8, 'Patients Details Information', style_blue_li)
        sheet.write(3, 0, 'appointment_count', style_blue_dk)
        sheet.write(3, 1, 'patient_name', style_blue_li)
        sheet.write(3, 2, 'patient_id', style_grey_li)
        sheet.write(3, 3, 'patient_age', style_blue_li)
        sheet.write(3, 4, 'patient_mobile_no', style_blue_li)
        sheet.write(3, 5, 'Country_id', style_green_dk)
        sheet.write(3, 6, 'Gender', style_blue_li)
        sheet.write(3, 7, 'patient_dob', style_blue_li)
        sheet.write(3, 8, 'age_group', style_blue_li)

        ids = self.env['hospital.patient'].search([])
        row = 4
        for rec in ids:
            print('row1', row)
            print('rec', rec)
            sheet.write(row, 0, rec.appointment_count, style_grey_li)
            sheet.row(6).height = 200
            sheet.write(row, 1, rec.patient_name, style_grey_li)
            sheet.write(row, 2, rec.patient_id, style_grey_li)
            sheet.write(row, 3, rec.patient_age, style_grey_li)
            sheet.write(row, 4, rec.patient_mobile_no, style_grey_li)
            sheet.write(row, 5, rec.country_id.name, style_grey_li)
            sheet.write(row, 6, rec.gender, style_grey_li)
            sheet.write(row, 7, rec.patient_dob, style_grey_li)
            sheet.write(row, 8, rec.age_group, style_grey_li)
            row = row + 1
        print('row2', row)
        sheet.write()
        # important for excel report
        xlwt.add_palette_colour("custom_colour_or", 0x21)
        date_format = xlwt.XFStyle()
        date_format.num_format_str = 'dd/mm/yyyy'
        date_format = xlwt.XFStyle()
        date_format.num_format_str = 'dd/mm/yyyy'
        filename = 'test.xls'

        fp = BytesIO()
        wb.save(fp)
        out = base64.encodebytes(fp.getvalue())
        view_report_status_id = self.env['view.xls.report'].create({'file_name': out, 'datas_fname': filename})
        return {
            'res_id': view_report_status_id.id,
            'name': 'Employee',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'view.xls.report',
            'view_id': False,
            'type': 'ir.actions.act_window',
        }

    class view_xls_report(models.TransientModel):
            _name = 'view.xls.report'
            _rec_name = 'datas_fname'
            datas_fname = fields.Char('File Name', size=256)
            file_name = fields.Binary('Report')

