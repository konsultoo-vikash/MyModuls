from odoo import fields, models, api


class HospitalDoctor(models.Model):
    _name = 'hospital.doctor'
    _rec_name = 'doctor_name'

                               # Compute function

    @api.depends('age_group')
    def set_age_group(self):
        for rec in self:
            if rec.doctor_age:
                if rec.doctor_age < 18:
                    rec.age_group = 'primary'
                else:
                    rec.age_group = 'secondary'


                                #odoo fields
    image = fields.Binary(string='Image')
    doctor_name = fields.Char(string='doctor name')
    doctor_dob = fields.Date(string='Date of Birth')
    doctor_mobile_no = fields.Char(string='Mobile')
    gender = fields.Selection([('male', 'Male'),
                               ('female', 'Female'),
                               ('others', 'Others')], string='Gender')
    remarks = fields.Char(string='Remarks')
    doctor_age = fields.Integer(string='Age')
    age_group = fields.Selection([
        ('primary', 'Primary'),
        ('secondary', 'secondary'),
    ], string='age group', compute='set_age_group')
