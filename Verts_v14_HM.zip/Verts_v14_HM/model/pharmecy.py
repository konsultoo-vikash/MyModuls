from odoo import fields, models


class HospitalPharmacy(models.Model):
    _name = 'hospital.pharmacy'

    serial_no = fields.Integer(string='serial no')
    medicine_name = fields.Char(string='medicine name')
    currency_id = fields.Many2one('res.currency', string='Currency')
    medicine_price = fields.Monetary('Liquidated Damages')
    manufacturing_date = fields.Date(string='manufacturing date')
    expiry_date = fields.Date(string='expiry date')
    buyer_name = fields.One2many('res.partner', 'title', string='buyer name')
    buyer_remarks = fields.Text(string='remarks')

    # Inheriting the Res partner Model and Adding New Field


class ResPartner(models.Model):
    _inherit = 'res.partner'
    company_type = fields.Selection(selection_add=[('Apple Inc', 'Apple Inc'), ('Microsoft Inc', 'Microsoft Inc')])
