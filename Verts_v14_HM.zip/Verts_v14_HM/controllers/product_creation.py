from odoo.http import request
from odoo import api, http


class Product(http.Controller):
    @http.route(['/product/creation/apply'], type='http', auth="user", website=True)
    def product_creation_apply(self, **kwargs):
        print('post', **kwargs)

        products = request.env['hospital.patient'].sudo().search([])
        # location_details = request.env['stock.location'].sudo().search([('unassigned_location','=',True)],limit=1)
        pick_id = request.env['hospital.patient'].sudo().search({'patient_id': int(kwargs['patient_id'])})

        print('products', products)
        values = {
            'products': products,
            # 'location_details': location_details,
            'pick_id': pick_id,
        }
        print('values', values)
        return request.render("Verts_v14_HM.records_creation", values)
